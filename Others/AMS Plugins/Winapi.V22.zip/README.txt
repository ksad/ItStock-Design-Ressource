All of the examples in Examples folder were built with AutoPlay Media Studio 6
And some of them may require small changes due to Lua version diffrences