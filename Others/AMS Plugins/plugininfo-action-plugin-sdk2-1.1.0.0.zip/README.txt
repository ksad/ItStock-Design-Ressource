Imagine PluginInfo Action Plugin and example
� by Imagine Programming 2010, All rights reserved!

Included:
Example: PluginInfo Example.apz
Plugin: Folder[PluginInfo], put this in AMS8Dir/Plugins/Actions